(() => {
  const COPY_ID = 'chatgpt-copy-bubble';
  const OFFSET_X = 24;
  const OFFSET_Y = 24;
  const HIDE_DELAY = 3000;
  let copyEl, selectedText = '', lastX = 0, lastY = 0;

  function createBubble(id, emoji) {
    const el = document.createElement('div');
    el.id = id;
    el.textContent = emoji;
    el.dataset.originalText = emoji;
    el.style.cssText = `
      position: absolute;
      padding: 0;
      background: transparent;
      color: #fff;
      border: none;
      font-size: 28px;
      font-family: sans-serif;
      cursor: pointer;
      z-index: 99999;
      user-select: none;
      box-shadow: none;
      transition: opacity 0.2s ease;
    `;
    el.style.opacity = '0';
    el.style.display = 'none';
    document.body.appendChild(el);
    return el;
  }

  function showBubble(el, x, y) {
    el.style.left = `${x + OFFSET_X}px`;
    el.style.top = `${y + OFFSET_Y}px`;
    el.style.opacity = '1';
    el.style.pointerEvents = 'auto';
    el.style.display = 'block';

    setTimeout(() => {
      const stillSelected = window.getSelection().toString().trim().length > 0;
      if (!stillSelected) {
        hideBubble(el);
      }
    }, HIDE_DELAY);
  }

  function hideBubble(el) {
    el.style.opacity = '0';
    el.style.pointerEvents = 'none';
    el.style.display = 'none';
    if (el.dataset.originalText) {
      el.textContent = el.dataset.originalText;
    }
  }

  function onMouseUp(e) {
    setTimeout(() => {
      const sel = window.getSelection();
      const text = sel ? sel.toString().trim() : '';
      if (text.length > 0) {
        selectedText = text;
        lastX = e.pageX;
        lastY = e.pageY;
        showBubble(copyEl, lastX, lastY);
      } else {
        hideBubble(copyEl);
      }
    }, 120);
  }

  function copyText() {
    navigator.clipboard.writeText(selectedText).then(() => {
      copyEl.textContent = '✅';
      setTimeout(() => hideBubble(copyEl), 1000);
    }).catch(err => {
      copyEl.textContent = '❌';
      console.error('Copy error:', err);
      setTimeout(() => hideBubble(copyEl), 1000);
    });
  }

  function init() {
    if (document.getElementById(COPY_ID)) return;
    copyEl = createBubble(COPY_ID, '📑');
    copyEl.onclick = () => copyText();
    document.addEventListener('mouseup', onMouseUp);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();